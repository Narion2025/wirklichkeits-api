
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const port = process.env.PORT || 10000;

app.use(cors());
app.use(bodyParser.json());

const triggerFile = path.join(__dirname, 'lastTrigger.json');

app.get('/', (req, res) => {
  res.send('Wirklichkeits-API läuft. Endpunkte: POST /trigger, GET /status');
});

app.post('/trigger', (req, res) => {
  const trigger = req.body;
  fs.writeFileSync(triggerFile, JSON.stringify(trigger, null, 2));
  console.log('🌀 Trigger gespeichert:', trigger);
  res.send('Neuer Trigger empfangen!');
});

app.get('/status', (req, res) => {
  if (fs.existsSync(triggerFile)) {
    const data = fs.readFileSync(triggerFile);
    res.type('json').send(data);
  } else {
    res.json({});
  }
});

app.post('/clear', (req, res) => {
  if (fs.existsSync(triggerFile)) fs.unlinkSync(triggerFile);
  res.send('Trigger wurde gelöscht.');
});

app.get('/terms', (req, res) => {
  res.send('Diese API speichert keine personenbezogenen Daten.');
});

app.listen(port, () => {
  console.log(`🔊 Wirklichkeits-API (Always-Trigger) bereit auf Port ${port}`);
});
