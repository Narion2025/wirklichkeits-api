# Wirklichkeits-API für Narion

Dieses Projekt stellt eine einfache API bereit, die Trigger empfängt, speichert und auf Anfrage wieder ausgibt.

- `POST /trigger`: Setzt einen neuen Trigger
- `GET /status`: Liefert den letzten Trigger
- `POST /clear`: Löscht den aktuellen Trigger
- `GET /terms`: Zeigt Datenschutzinfo

Bereit für Deployment auf Render.com
